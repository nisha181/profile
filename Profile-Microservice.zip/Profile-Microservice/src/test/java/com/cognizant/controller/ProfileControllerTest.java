package com.cognizant.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.cache.ProfileDaoCache;
import com.cognizant.model.ProfileModel;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(value = ProfileController.class)
class ProfileControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	ProfileDaoCache profileService;
	


	static ProfileModel testProfile=new ProfileModel(1L, "Profile X", "Order", "OrderType", "POS", "Y");
	static ProfileModel testProfile2;
	static List<ProfileModel>profiles=new ArrayList<ProfileModel>();
	static ResponseEntity<List<ProfileModel>>responseEntity;

	
		
		@BeforeEach
		public void init() {
			
		profiles.add(new ProfileModel(1L, "Profile X", "Order", "OrderType", "POS", "Y"));
		profiles.add(new ProfileModel(2L, "Profile Y", "Order", "OrderType", "POS", "Y"));
		}

	@Test
	void testGetAllProfileDetails() throws Exception {
		when(profileService.findAll()).thenReturn(ResponseEntity.status(HttpStatus.OK).body(profiles));
		assertEquals(profileService.findAll(), ResponseEntity.status(HttpStatus.OK).body(profiles));
		mockMvc.perform(get("/profile/details")).equals(profiles);
	}

	@Test
	void testSaveProfile() throws Exception {
		ProfileModel model=new ProfileModel(1L, "Profile X", "Order", "OrderType", "POS", "Y");
		
		when(profileService.save(model)).thenReturn(ResponseEntity.status(HttpStatus.OK).body(model));
		ObjectMapper mapper = new ObjectMapper();
		String str = mapper.writeValueAsString(model);
		mockMvc.perform(post("/profile/saveprofile").contentType(org.springframework.http.MediaType.APPLICATION_JSON).content(str)).andExpect(status().isOk());
		
		
	}
	@Test
	void testUpdateProfile() throws Exception {
		ProfileModel model=new ProfileModel(1L, "Profile X", "Order", "OrderType", "POS", "Y");
		
		when(profileService.updateProfile(model)).thenReturn(ResponseEntity.status(HttpStatus.OK).body(model));
		ObjectMapper mapper = new ObjectMapper();
		String str = mapper.writeValueAsString(model);
		mockMvc.perform(put("/profile/updateprofile").contentType(org.springframework.http.MediaType.APPLICATION_JSON).content(str)).andExpect(status().isOk());
		
	}

	@Test
	void testDeleteProfile() throws   Exception {
		when(profileService.deleteProfile(1L)).thenReturn(ResponseEntity.status(HttpStatus.OK).body("Profile id 1 deleted successfully"));
		mockMvc.perform(delete("/profile/deleteprofile/1")).andExpect(status().isOk());
	}
	

}
