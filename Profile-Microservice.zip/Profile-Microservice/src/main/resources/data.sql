insert into Profile("PROFILE_ID"  ,	"CRITERIA_NAME",  	"CRITERIA_VALUE" , 	"GENERATE_SHIPMENT"  ,	"PROFILE_NAME",  	"PROFILE_TYPE"  
) values 
(100,'Order Type','Point of Sale Order','Y','Nayan','Order'),
(200,'Order Type','Web Order','Y','Nilu','Order'),
(300,'Order Type','Standard Order','N','Nisha','Order'),
(400,'Order Type','Point of Sale Order','N','Anindita','Order'),
(500,'Order Type','Web Order','Y','Sourav','Order');