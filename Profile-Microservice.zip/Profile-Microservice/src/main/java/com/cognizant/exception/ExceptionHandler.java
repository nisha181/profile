package com.cognizant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cognizant.model.ResponseMessage;

import lombok.NoArgsConstructor;

/**
 * @author nisha
 *
 */
@RestControllerAdvice
@NoArgsConstructor
public class ExceptionHandler {

	/**
	 * @param e1
	 * @return
	 */


	@org.springframework.web.bind.annotation.ExceptionHandler
	public  ResponseEntity<ResponseMessage> handleException(final ProfileNotFoundException exception) {
		return new ResponseEntity<>(
					new ResponseMessage(HttpStatus.NOT_FOUND, exception.getMessage()),
					HttpStatus.NOT_FOUND
				);
	}
	
	


}