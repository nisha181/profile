package com.cognizant;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;


import org.springframework.context.annotation.Bean;

import com.google.common.base.Predicate;

import springfox.documentation.builders.ApiInfoBuilder;

import springfox.documentation.builders.PathSelectors;

import springfox.documentation.service.ApiInfo;

import springfox.documentation.spi.DocumentationType;

import springfox.documentation.spring.web.plugins.Docket;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SuppressWarnings("deprecation")

@SpringBootApplication

@EnableSwagger2

public class ProfileMicroserviceApplication {

	public static void main(String[] args) {

		SpringApplication.run(ProfileMicroserviceApplication.class, args);

	}

	/**
	 * 
	 * Defines Docket Bean
	 * 
	 * @return
	 * 
	 */

	private Predicate<String> myPaths() {

		return PathSelectors.regex("/profile/.*");

	}

	@Bean

	public Docket swaggerConfiguration() {

		return new Docket(DocumentationType.SWAGGER_2).groupName("public-api").apiInfo(apiInfo()).select()

				.paths(myPaths()).build();

	}

	private ApiInfo apiInfo() {

		return new ApiInfoBuilder().title("Profile API").description("Profile API reference for developers")

				.termsOfServiceUrl("https://cognizant.com")
				.license("Cognizant License")

				.licenseUrl("nishadalal@gmail.com").version("1.0").build();

	}

}
