package com.cognizant.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@XmlRootElement
@Table(name = "Profile")
@SuppressWarnings("deprecation")
public class ProfileModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull(message = "Profile id musn't be blank")
	@Column(name = "PROFILE_ID")
	private Long profileId;

	
	@Column(name = "PROFILE_NAME")
	private String profileName;

	
	@Column(name = "PROFILE_TYPE")
	private String profileType;

	
	@Column(name = "CRITERIA_NAME")
	private String criteriaName;

	
	@Column(name = "CRITERIA_VALUE")
	private String criteriaValue;

	
	@Column(name = "GENERATE_SHIPMENT")
	private String generateShipment;

}
